#!/bin/bash

start_sh_server
start_code_server

python3 ./ignite.py

infinite_loop