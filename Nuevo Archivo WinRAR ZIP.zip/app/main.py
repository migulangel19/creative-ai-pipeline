import json
import logging
import base64  # Added for base64 encoding
from typing import Dict

from ontology_dc8f06af066e4a7880a5938933236037.config import ConfigClass
from ontology_dc8f06af066e4a7880a5938933236037.input import InputClass
from ontology_dc8f06af066e4a7880a5938933236037.output import OutputClass
from openfabric_pysdk.context import AppModel, State
from core.stub import Stub

import requests

# Configurations dictionary for storing user configs
configurations: Dict[str, ConfigClass] = dict()

############################################################
# Config callback function
############################################################
def config(configuration: Dict[str, ConfigClass], state: State) -> None:
    """
    Stores user-specific configuration data.

    Args:
        configuration: Mapping of user IDs to configuration objects.
        state: Current application state (not used here).
    """
    for uid, conf in configuration.items():
        logging.info(f"Saving new config for user with id:'{uid}'")
        configurations[uid] = conf

############################################################
# Execution callback function
############################################################
def execute(model: AppModel) -> None:
    """
    Main execution entry point for handling a model pass.

    Args:
        model: The model object containing request and response.
    """

    # Retrieve input prompt from the request
    request: InputClass = model.request

    # Retrieve super-user config
    user_config: ConfigClass = configurations.get('super-user', None)
    logging.info(f"{configurations}")

    # Initialize list of app IDs for Stub
    app_ids = user_config.app_ids if user_config else []

    # Ensure both app IDs are included
    text_to_image_id = "c25dcd829d134ea98f5ae4dd311d13bc.node3.openfabric.network"
    image_to_3d_id = "166d2212647b4a44ac48edada6bff3d3.node3.openfabric.network"
    
    if text_to_image_id not in app_ids:
        app_ids.append(text_to_image_id)
    if image_to_3d_id not in app_ids:
        app_ids.append(image_to_3d_id)

    # Initialize Stub with the app IDs
    stub = Stub(app_ids)

    # ------------------------------
    # TODO : add your magic here
    # ------------------------------
    try:
        # Call LLaMA to expand the prompt
        logging.info(f"Original prompt: {request.prompt}")
        llama_response = requests.post("http://ollama:11434/api/generate", json={
            "model": "llama3",
            "prompt": f"Expand this prompt to generate a detailed image description (max 60 words): {request.prompt}",
            "stream": False
        }, timeout=180)

        llama_response.raise_for_status()
        expanded_prompt = llama_response.json().get("response", "").strip()
        
        # Ensure prompt doesn't exceed 60 words
        words = expanded_prompt.split()
        if len(words) > 60:
            expanded_prompt = " ".join(words[:60])
            
        logging.info(f"Expanded prompt ({len(expanded_prompt.split())} words): {expanded_prompt}")

    except Exception as e:
        logging.error(f"Error calling LLaMA: {e}")
        # Use original prompt as fallback
        expanded_prompt = request.prompt

    # Abort if prompt expansion failed
    if not expanded_prompt:
        response: OutputClass = model.response
        response.message = "Prompt expansion failed."
        return

    try:
        # Check connectivity to each app
        for app_id in app_ids:
            if app_id in stub._connections:
                logging.info(f"Connected to app: {app_id}")
            else:
                logging.warning(f"Not connected to app: {app_id}")

        # Step 1: Call the Text-to-Image app
        logging.info("Step 1: Generating image from text...")
        image_result = stub.call(
            text_to_image_id,
            {"prompt": expanded_prompt},
            "super-user"
        )

        # Get the raw image data (bytes)
        image_data = image_result.get("result")
        if not image_data:
            raise Exception("No image data returned from Text-to-Image app.")

        logging.info(f"Image data received: {type(image_data)}, size: {len(image_data)} bytes")

        # Save the image locally as output.png
        with open("output.png", "wb") as f:
            f.write(image_data)
        logging.info("Image generated and saved as output.png")

        # Step 2: Convert image to 3D model
        logging.info("Step 2: Converting image to 3D model...")
        
        # Encode the image in base64 for the Image-to-3D app
        encoded_image = base64.b64encode(image_data).decode('utf-8')
        logging.info(f"Image encoded to base64: {len(encoded_image)} characters")

        # CORRECCIÓN: Incluir el prefijo del tipo de datos
        # El servicio espera el formato completo data:image/png;base64,
        image_with_prefix = encoded_image
        
        # Prepare payload according to schema
        three_d_payload = {"input_image": image_with_prefix}
        
        logging.info(f"Payload prepared with data prefix, total length: {len(image_with_prefix)}")
        
        # Call the Image-to-3D app
        logging.info("Calling Image-to-3D service...")
        three_d_result = stub.call(
            image_to_3d_id,
            three_d_payload,
            "super-user"
        )
        
        if not three_d_result:
            raise Exception("No response from 3D conversion service")
            
        logging.info(f"3D service response keys: {list(three_d_result.keys())}")
        
        # Process the 3D model result
        model_data = three_d_result.get("generated_object")
        
        
        if model_data:
            # Handle the 3D model data
            if isinstance(model_data, str):
                # If it's a string, it might be base64 encoded
                try:
                    model_bytes = base64.b64decode(model_data)
                except:
                    # If base64 decode fails, treat as raw bytes
                    model_bytes = model_data.encode() if isinstance(model_data, str) else model_data
            else:
                model_bytes = model_data
            
            # Save the 3D model
            with open("output.glb", "wb") as f:
                f.write(model_bytes)
            logging.info(f"3D model saved as output.glb ({len(model_bytes)} bytes)")
        else:
            logging.warning("No 3D model data in response")
            

        # Set success response
        response: OutputClass = model.response
        response.message = f"Successfully generated image and 3D model from prompt: '{expanded_prompt}'"
        logging.info("Pipeline completed successfully!")

    except Exception as e:
        logging.error(f"Error in pipeline: {str(e)}", exc_info=True)
        response: OutputClass = model.response
        response.message = f"Pipeline failed: {str(e)}"
